package ca.sheridancollege.project;

/**
 * UNO card colors.
 */
public enum Color {
    RED, YELLOW, GREEN, BLUE, WILD
}
