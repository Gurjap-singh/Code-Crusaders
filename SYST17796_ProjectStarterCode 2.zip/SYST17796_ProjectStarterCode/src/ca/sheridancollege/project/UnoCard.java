package ca.sheridancollege.project;
public class UnoCard extends Card {

    private final Color color;
    private final Value value;

    public UnoCard(Color color, Value value) {
        this.color = color;
        this.value = value;
    }

    public Color getColor() {
        return color;
    }

    public Value getValue() {
        return value;
    }

    @Override
    public String toString() {
        if (color == Color.WILD) {
            return value.name(); 
        } else {
            return color.name() + " " + value.name();
        }
    }
}
