package ca.sheridancollege.project;

import java.util.ArrayList;
import java.util.Scanner;


public class UnoPlayer extends Player {

    private final GroupOfCards hand;

   
    private final boolean human;

    public UnoPlayer(String name, boolean human) {
        super(name);
        this.human = human;
        this.hand = new GroupOfCards(0);
    }

    public GroupOfCards getHand() {
        return hand;
    }

    public void addCard(Card c) {
        hand.getCards().add(c);
    }

    public void addCards(ArrayList<Card> cards) {
        hand.getCards().addAll(cards);
    }

    public void removeCard(Card c) {
        hand.getCards().remove(c);
    }

    public int handSize() {
        return hand.getCards().size();
    }

   
    @Override
    public void play() {
   
    }

   
    public int chooseCardToPlay(UnoCard topCard) {
        ArrayList<Card> cards = hand.getCards();
        if (human) {
            
            Scanner scanner = new Scanner(System.in);
            System.out.println("Top card: " + (topCard == null ? "none" : topCard));
            System.out.println(getName() + "'s hand:");
            for (int i = 0; i < cards.size(); i++) {
                System.out.println(i + ": " + cards.get(i));
            }
            System.out.println("Enter card index to play or -1 to draw:");
            while (true) {
                try {
                    int idx = Integer.parseInt(scanner.nextLine().trim());
                    if (idx >= -1 && idx < cards.size()) return idx;
                } catch (NumberFormatException e) {
                   
                }
                System.out.println("Invalid input. Enter a valid index or -1 to draw:");
            }
        } else {
        
            for (int i = 0; i < cards.size(); i++) {
                Card c = cards.get(i);
                if (c instanceof UnoCard) {
                    UnoCard uc = (UnoCard) c;
                    if (UnoGame.isValidPlayStatic(uc, topCard)) {
                        return i;
                    }
                }
            }
        
            return -1;
        }
    }
}
