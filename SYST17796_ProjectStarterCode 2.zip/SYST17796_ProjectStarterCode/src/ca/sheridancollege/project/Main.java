package ca.sheridancollege.project;

import java.util.Scanner;

/**
 * Main console runner to start UNO game.
 */
public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("UNO - Console Game (Deliverable 3)");
        System.out.println("Enter number of players (2-4):");
        int num;
        while (true) {
            try {
                num = Integer.parseInt(scanner.nextLine().trim());
                if (num >= 2 && num <= 4) break;
            } catch (Exception e) {}
            System.out.println("Please enter a valid number between 2 and 4:");
        }

        UnoGame game = new UnoGame("UNO by Code-Crusaders");

        for (int i = 1; i <= num; i++) {
            System.out.println("Enter name for player " + i + ":");
            String name = scanner.nextLine().trim();
            System.out.println("Is this player human? (y/n):");
            String isHuman = scanner.nextLine().trim().toLowerCase();
            boolean human = isHuman.startsWith("y");
            UnoPlayer p = new UnoPlayer(name.isEmpty() ? ("Player" + i) : name, human);
            game.addPlayer(p);
        }

        // start & play
        game.startGame();
        game.play();
    }
}
