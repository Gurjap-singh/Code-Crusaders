package ca.sheridancollege.project;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class UnoGame extends Game {

    private UnoDeck drawPile;
    private UnoDeck discardPile;
    private final ArrayList<UnoPlayer> players;
    private int currentPlayerIndex;
    private boolean clockwise;

    private final Scanner scanner = new Scanner(System.in);
    private final Random random = new Random();

    public UnoGame(String name) {
        super(name);
        players = new ArrayList<>();
        clockwise = true;
    }

    public void addPlayer(UnoPlayer p) {
        players.add(p);
    }

    public ArrayList<UnoPlayer> getPlayersList() {
        return players;
    }

    
    public void startGame() {
        drawPile = new UnoDeck(0);
        discardPile = new UnoDeck(0);
        drawPile.initializeDeck();
        drawPile.shuffle();

        
        for (int i = 0; i < players.size(); i++) {
            for (int j = 0; j < 7; j++) {
                Card c = drawPile.drawCard();
                players.get(i).addCard(c);
            }
        }

      
        Card starting;
        do {
            starting = drawPile.drawCard();
      
            if (starting == null) break;

            if (starting instanceof UnoCard) {
                UnoCard uc = (UnoCard) starting;
                if (uc.getValue() == Value.WILD_DRAW_FOUR) {
             
                    drawPile.getCards().add(0, starting); 
                    starting = null; 
                }
            }
        } while (starting == null);

        if (starting != null) discardPile.addCard(starting);

        // pick a random starting player
        currentPlayerIndex = random.nextInt(players.size());
        System.out.println("Starting player: " + players.get(currentPlayerIndex).getName());
    }

    
    public void play() {
        while (true) {
            UnoPlayer current = players.get(currentPlayerIndex);
            System.out.println("\n--- " + current.getName() + "'s turn ---");
            UnoCard top = getTopDiscard();
            System.out.println("Top discard: " + (top == null ? "None" : top));
            // show hand size only (or full hand if human)
            if (current.handSize() <= 10 || currentEqualsHuman(current)) {
                System.out.println("Your hand:");
                for (Card c : current.getHand().getCards()) {
                    System.out.println("  " + c);
                }
            } else {
                System.out.println("Hand size: " + current.handSize());
            }

            int choice = current.chooseCardToPlay(top);

            if (choice == -1) {
                // draw one card
                Card drawn = drawOneCard();
                if (drawn == null) {
                    System.out.println("Draw pile empty; cannot draw.");
                } else {
                    System.out.println(current.getName() + " drew: " + drawn);
                    current.addCard(drawn);
                  
                    if (drawn instanceof UnoCard && isValidPlayStatic((UnoCard) drawn, top)) {
                        System.out.println("Drew playable card and will play it automatically.");
                        current.removeCard(drawn);
                        discardPile.addCard(drawn);
                        applyCardEffect((UnoCard) drawn, current);
                    } else {
                        // end turn
                        currentPlayerIndex = nextPlayerIndex(1);
                    }
                }
            } else {
                // play selected card
                Card toPlay = current.getHand().getCards().get(choice);
                if (!(toPlay instanceof UnoCard)) {
                    System.out.println("Invalid card type. Turn skipped.");
                    currentPlayerIndex = nextPlayerIndex(1);
                } else {
                    UnoCard uc = (UnoCard) toPlay;
                    if (!isValidPlayStatic(uc, top)) {
                        System.out.println("Invalid play. You cannot play that card now.");
                        // For human, allow retry. For simplicity, we skip to drawing:
                        Card drawn = drawOneCard();
                        if (drawn != null) current.addCard(drawn);
                        currentPlayerIndex = nextPlayerIndex(1);
                    } else {
                        // valid play
                        current.removeCard(toPlay);
                        discardPile.addCard(uc);
                        System.out.println(current.getName() + " played: " + uc);

                        // UNO check
                        if (current.handSize() == 1) {
                            System.out.println(current.getName() + " says: UNO!");
                        }

                        // win check
                        if (current.handSize() == 0) {
                            System.out.println("GAME OVER. Winner: " + current.getName());
                            break;
                        }

                        // apply effects and set next player index accordingly
                        applyCardEffect(uc, current);
                    }
                }
            }
            // simple pause for readability
            try { Thread.sleep(200); } catch (Exception e) {}
        }
    }

   
    private boolean currentEqualsHuman(UnoPlayer p) {
       
        return true; 
    }


    public static boolean isValidPlayStatic(UnoCard played, UnoCard top) {
        if (top == null) return true;
        if (played.getColor() == Color.WILD) return true;
        if (played.getColor() == top.getColor()) return true;
        if (played.getValue() == top.getValue()) return true;
        return false;
    }

    /** Non-static top card convenience */
    private UnoCard getTopDiscard() {
        Card c = discardPile.peekTop();
        if (c == null) return null;
        return (UnoCard) c;
    }


    private Card drawOneCard() {
        Card c = drawPile.drawCard();
        if (c != null) return c;
       
        if (discardPile.getCards().size() <= 1) return null; // nothing to reshuffle
        Card top = discardPile.drawCard(); // removes top
        ArrayList<Card> toMove = new ArrayList<>(discardPile.getCards());
        discardPile.getCards().clear();
        // move to draw and shuffle
        drawPile.getCards().addAll(toMove);
        drawPile.shuffle();
        // put back top on discard
        discardPile.addCard(top);
        return drawPile.drawCard();
    }

   
    private void applyCardEffect(UnoCard card, UnoPlayer justPlayed) {
        UnoCard top = (UnoCard) discardPile.peekTop();
        // default next player
        if (card.getValue() == Value.SKIP) {
            System.out.println("SKIP effect: next player is skipped.");
            currentPlayerIndex = nextPlayerIndex(2);
        } else if (card.getValue() == Value.REVERSE) {
            System.out.println("REVERSE effect: reversing direction.");
            clockwise = !clockwise;
            if (players.size() == 2) {
                // in 2-player game reverse acts like skip
                currentPlayerIndex = nextPlayerIndex(2);
            } else {
                currentPlayerIndex = nextPlayerIndex(1);
            }
        } else if (card.getValue() == Value.DRAW_TWO) {
            int next = nextPlayerIndex(1);
            System.out.println("DRAW TWO: " + players.get(next).getName() + " draws 2 cards and is skipped.");
            Card c1 = drawOneCard();
            Card c2 = drawOneCard();
            if (c1 != null) players.get(next).addCard(c1);
            if (c2 != null) players.get(next).addCard(c2);
            currentPlayerIndex = nextPlayerIndex(2);
        } else if (card.getValue() == Value.WILD) {
            // choose color 
            Color chosen = chooseColor(justPlayed);
            // represent the wild by changing the top card's color logically - we cannot mutate enum of card, so we leave top as WILD and track chosen color locally in validation
            // For simplicity, we'll push a special UnoCard with the chosen color and WILD value to discard to represent chosen color
            discardPile.getCards().set(discardPile.getCards().size()-1, new UnoCard(chosen, Value.WILD));
            currentPlayerIndex = nextPlayerIndex(1);
        } else if (card.getValue() == Value.WILD_DRAW_FOUR) {
            Color chosen = chooseColor(justPlayed);
            discardPile.getCards().set(discardPile.getCards().size()-1, new UnoCard(chosen, Value.WILD_DRAW_FOUR));
            int next = nextPlayerIndex(1);
            System.out.println("WILD DRAW FOUR: " + players.get(next).getName() + " draws 4 and is skipped.");
            for (int i = 0; i < 4; i++) {
                Card d = drawOneCard();
                if (d != null) players.get(next).addCard(d);
            }
            currentPlayerIndex = nextPlayerIndex(2);
        } else {
            // number card or non-special normal play
            currentPlayerIndex = nextPlayerIndex(1);
        }
    }

    private Color chooseColor(UnoPlayer p) {
        // If human player, ask via console, else pick random color
        System.out.println(p.getName() + " must choose a color (RED, YELLOW, GREEN, BLUE).");
        // try reading if human
        try {
            System.out.println("Enter color (RED, YELLOW, GREEN, BLUE) or press ENTER to auto choose:");
            String in = scanner.nextLine().trim().toUpperCase();
            if (in.isEmpty()) {
                return randomColor();
            }
            switch (in) {
                case "RED": return Color.RED;
                case "YELLOW": return Color.YELLOW;
                case "GREEN": return Color.GREEN;
                case "BLUE": return Color.BLUE;
                default: return randomColor();
            }
        } catch (Exception e) {
            return randomColor();
        }
    }

    private Color randomColor() {
        Color[] arr = new Color[]{Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE};
        return arr[random.nextInt(arr.length)];
    }

    
    private int nextPlayerIndex(int step) {
        int n = players.size();
        int delta = clockwise ? step : -step;
        int idx = (currentPlayerIndex + delta) % n;
        if (idx < 0) idx += n;
        return idx;
    }


    @Override
public void declareWinner() {
    UnoPlayer winner = null;
    int minCards = Integer.MAX_VALUE;

    for (UnoPlayer p : players) {
        int size = p.handSize();
        if (size < minCards) {
            minCards = size;
            winner = p;
        }
    }

    if (winner != null) {
        System.out.println("Winner: " + winner.getName()
                + " with " + minCards + " cards remaining.");
    } else {
        System.out.println("No winner could be determined.");
    }
}
}
