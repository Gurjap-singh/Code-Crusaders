
package ca.sheridancollege.project;


public abstract class Card {
    
    @Override
    public abstract String toString();

}
