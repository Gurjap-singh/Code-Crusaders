package ca.sheridancollege.project;

import java.util.ArrayList;

/**
 * UnoDeck extends GroupOfCards. Uses getCards() to access underlying list.
 */
public class UnoDeck extends GroupOfCards {

    public UnoDeck(int size) {
        super(size);
        // leave actual initialization to initializeDeck()
    }

    /**
     * Initialize full UNO deck (approximate standard composition).
     * We'll create: for each color: 1 ZERO, two of 1-9, two SKIP, two REVERSE, two DRAW_TWO.
     * Plus 4 WILD, 4 WILD_DRAW_FOUR.
     */
    public void initializeDeck() {
        ArrayList<Card> cards = getCards();
        cards.clear();

        for (Color c : new Color[]{Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE}) {
            // one ZERO
            cards.add(new UnoCard(c, Value.ZERO));
            // two of 1-9
            for (Value v : new Value[]{Value.ONE, Value.TWO, Value.THREE, Value.FOUR, Value.FIVE, Value.SIX, Value.SEVEN, Value.EIGHT, Value.NINE}) {
                cards.add(new UnoCard(c, v));
                cards.add(new UnoCard(c, v));
            }
            // two SKIP, two REVERSE, two DRAW_TWO
            cards.add(new UnoCard(c, Value.SKIP));
            cards.add(new UnoCard(c, Value.SKIP));
            cards.add(new UnoCard(c, Value.REVERSE));
            cards.add(new UnoCard(c, Value.REVERSE));
            cards.add(new UnoCard(c, Value.DRAW_TWO));
            cards.add(new UnoCard(c, Value.DRAW_TWO));
        }
        // 4 wilds and 4 wild draw fours
        for (int i = 0; i < 4; i++) {
            cards.add(new UnoCard(Color.WILD, Value.WILD));
            cards.add(new UnoCard(Color.WILD, Value.WILD_DRAW_FOUR));
        }
    }

    /**
     * Draw the top card (end of list considered top). Returns null if empty.
     */
    public Card drawCard() {
        ArrayList<Card> cards = getCards();
        if (cards.isEmpty()) return null;
        return cards.remove(cards.size() - 1);
    }

    /**
     * Peek top card without removing; return null if none.
     */
    public Card peekTop() {
        ArrayList<Card> cards = getCards();
        if (cards.isEmpty()) return null;
        return cards.get(cards.size() - 1);
    }

    /**
     * Add a card to top of deck.
     */
    public void addCard(Card c) {
        getCards().add(c);
    }
}
