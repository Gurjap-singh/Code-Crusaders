package ca.sheridancollege.project;

/**
 * UNO card implementation that extends the starter Card abstraction.
 */
public class UnoCard extends Card {

    private final Color color;
    private final Value value;

    public UnoCard(Color color, Value value) {
        this.color = color;
        this.value = value;
    }

    public Color getColor() {
        return color;
    }

    public Value getValue() {
        return value;
    }

    @Override
    public String toString() {
        if (color == Color.WILD) {
            return value.name(); // "WILD" or "WILD_DRAW_FOUR"
        } else {
            return color.name() + " " + value.name();
        }
    }
}
